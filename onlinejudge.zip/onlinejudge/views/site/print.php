<?php

use yii\helpers\Html;

$this->title = 'T36 Online Judge';
?>
<div class="site-index">
    <div class="jumbotron">
        <h1>Hello, world!</h1>
        <p>Welcome to T36OJ - T36 Online Judge</p>
        <hr>
        <p>Power by Greenhat1998.</p>
		<p>The People's Police University of Technology and Logictics.</p>
    </div>
</div>