<?php

namespace app\modules\polygon;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\polygon\controllers';

    public function init()
    {
        parent::init();
    }
}
